package ie.lyit.testers;
package ie.ie.lyit.serialize.*;
import ie.lyit.serialize.BookSerializer;

public class BookTester{
    public static void main(String [] args){
        BookSerializer bS = new BookSerializer();
        bS.add();
        bS.serializeBooks();
        bS.deserializeBooks();
    }
}
