package ie.lyit.serialize;
import java.util.ArrayList;
import ie.lyit.book.Book;
import java.io.*;


public class BookSerializer{
   private final String FILE_NAME = "C:/Users/Name/Java/Book/Books/Books.bin";
   private ArrayList<Book> books = new ArrayList<Book>();

   public void add(){
      Book book = new Book();
      book.read(); books.add(book);
   }

   public void serializeBooks(){
      ObjectOutputStream oOS = null;

      try{
         FileOutputStream fOS = new FileOutputStream(FILE_NAME);
         oOS = new ObjectOutputStream(fOS);
         oOS.writeObject(books);
      }
      catch(FileNotFoundException f){
         System.out.print("File not found" + f.getMessage());
      }
      catch(IOException io){
         System.out.print("IO Error " + io.getMessage());
      }
      finally{
         try{
            oOS.close();
         }
         catch(IOException io){
            System.out.print("IO Close Error " + io.getMessage());
         }
      }
   }

   public void deserializeBooks(){
      ObjectInputStream oIS = null;

      try{
         FileInputStream fIS = new FileInputStream(FILE_NAME);
         oIS = new ObjectInputStream(fIS);
         books = (ArrayList)oIS.readObject();
      }
      catch(FileNotFoundException f){
         System.out.print("File not found" + f.getMessage());
      }
      catch(IOException io){
         System.out.print("IO Error " + io.getMessage());
      }
      catch(ClassNotFoundException ce){
         System.out.print("Class not found Exception " + ce.getMessage());
      }
      finally{
         try{
            oIS.close();
         }
         catch(IOException io){
            System.out.print("IO Close Error " + io.getMessage());
         }
      }
   }

   public void list(){
      for(Book b : books){
          System.out.print(b.toString());
      }
   }
}
