package ie.lyit.flight;

public class Passenger extends Person 
{	
	protected int noOfBags;
    protected boolean priorityBoarding;

    public Passenger(){
        super();
        noOfBags = 0;
        priorityBoarding = false;
    }

    public Passenger(String title, String fName, String sName, int day, int month, int year, int noOfBags, boolean priorityBoarding){
        super(title, fName, sName, day, month, year);
        this.noOfBags = noOfBags;
        this.priorityBoarding = priorityBoarding;
    }

    // Setters for Passenger class
    public void setNoOfBags(int noOfBags){
        this.noOfBags = noOfBags;
    }

    public void setPriorityBoarding(boolean priorityBoarding){
        this.priorityBoarding = priorityBoarding;
    }

    // Getters for Passenger class
    public int getNoOfBags(){
        return noOfBags;
    }

    public boolean isPriority(){
        return priorityBoarding;
    }

    // equals() method for Passenger class
    public boolean equals(Passenger anotherPassenger){
        return (super.equals(anotherPassenger) &&
                noOfBags == anotherPassenger.noOfBags &&
                priorityBoarding == anotherPassenger.priorityBoarding);
    }

    // toString() method for Passenger class
    public String toString(){
        return super.toString() + "\n"
               + "Number of Bags: " + noOfBags + "\n"
               + "Priority Boarding: " + priorityBoarding;
    }
}
