

package ie.lyit.flight;

import java.io.Serializable;

public class Date implements Serializable {

   
   private int day;
   private int month;
   private int year;

   public Date() {
      day = 0;
      month = 0;
      year = 0;
   }

	 // Date constructor with Error checking
   public Date(int day, int month, int year) {
      int months [] = {1, 3, 5, 7, 8, 10, 12};
      boolean gotten = false;

			if(month < 1 || month > 12){
				throw new IllegalArgumentException("Month is less 1 or greater than 12");
			}
			else{
				this.month = month;		 if(year < 1900){
			 	throw new IllegalArgumentException("Year is less 1900");
		 }
		 else{
			 	this.year = year;
		 }
			}

      for(int m : months){
         if(m == month){
            if(day > 31 || day < 1){
               throw new IllegalArgumentException("Day is less than 1 or greater than 31 for this month");
            }
            else{
               this.day = day;
               gotten = true;
               break;
            }
         }
      }
      if(!gotten){
         if(day > 30 || day < 1){
            throw new IllegalArgumentException("Day is less than 1 or greater than 30 for this month");
         }
         else{
            this.day = day;
         }
      }


			if(year < 1900){
				 throw new IllegalArgumentException("Year is less than 1900");
			}
			else{
				 this.year = year;
			}
   }
	 // End Date constructor

   public int getDay() {
      return day;
   }

   public void setDay(int day) throws IllegalArgumentException {
      int months [] = {1, 3, 5, 7, 8, 10, 12};
      boolean gotten = false;
      for(int m : months){
         if(m == month){
            if(day > 31 || day < 1){
               throw new IllegalArgumentException("Day is less than 1 or greater than 31 for this month");
            }
            else{
               this.day = day;
               gotten = true;
               break;
            }
         }
      }
      if(!gotten){
         if(day > 30 || day < 1){
            throw new IllegalArgumentException("Day is less than 1 or greater than 30 for this month");
         }
         else{
            this.day = day;
         }
      }
   }

   public int getMonth() {
      return month;
   }

   public void setMonth(int month) throws IllegalArgumentException{
      if(month < 1 || month > 12){
					throw new IllegalArgumentException("Month is less 1 or greater than 12");
			}
			else{
					this.month = month;
			}
   }

   public int getYear(){
      return year;
   }

   public void setYear(int year) throws IllegalArgumentException{
		 if(year < 1900){
			 	throw new IllegalArgumentException("Year is less 1900");
		 }
		 else{
			 	this.year = year;
		 }
   }

   public String toString() {
      return "Day: " + day +  " Month: " + month 
         	   + " Year: " + year;
   }

   public boolean equals(Date date) {
      return(this.day == date.day
         	   && this.month == date.month
         	   && this.year == date.year);
   }
}
