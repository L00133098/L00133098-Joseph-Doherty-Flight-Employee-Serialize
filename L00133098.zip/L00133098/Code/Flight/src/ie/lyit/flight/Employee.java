package ie.lyit.flight;

import java.io.Serializable;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Employee extends Person implements Payable, Serializable
{
	protected double salary;
	private Date startDate;
	static protected int nextEmpNumber = 1000;
	private int empNumber;

	// Default constructor
	public Employee()
	{
		super();
		salary = 0.0;
		startDate = new Date();
		empNumber = nextEmpNumber++;
	}

	public void setemployeeNumber(int empNumber) 
	{
		this.empNumber = empNumber;
	}

	public int getemployeeNumber()
	{
		return empNumber;
	}

	public Employee(String title, String fName, String sName, int day, int month, int year, double salary,
			Date startDate) 
	{
		super(title, fName, sName, day, month, year);
		this.salary = salary;
		this.startDate = startDate;

	}
	
	
	// Setters for Employee class
	public void setSalary(double salary) 
	{
		this.salary = salary;
	}

	public void setStartDate(Date StartDate)
	{
		this.startDate = StartDate;
;
	}

	// Checks too see if the Employee number hasn't been used
	public void setEmpNum(int empNumber) 
	{
		
		if (empNumber > nextEmpNumber)
		{
			this.empNumber = empNumber;
			if (empNumber == nextEmpNumber) 
			{
				nextEmpNumber++;
			}
		} 
		else if (!(empNumber > nextEmpNumber))
		{
			this.empNumber = nextEmpNumber++;
		} else
		{
			this.empNumber = nextEmpNumber++;
		}
	}

	// Getters for Employee Class
	public double getSalary() 
	{
		return salary;
	}

	public String getStartDate() 
	{
		return startDate.toString();
	}

	public int getEmpNum()
	{
		return empNumber;
	}

	// toString() method for Employee class
	public String toString()
	{
		return "Employee Number: " + empNumber +"\n"+
				super.toString() + "\n" + "Salary: " + salary + "\n" + "Start Date: " + getStartDate() + "\n"
				;
	}

	// equals() method for Employee class
	public boolean equals(Employee anotherEmp) 
	{
		return (super.equals(anotherEmp) && salary == anotherEmp.salary && startDate == anotherEmp.startDate
				&& empNumber == anotherEmp.getEmpNum());
	}
	

	// Calculate the wage of an Employee
	@Override
	public double calculateWage(double taxPercentage) 
	{
		return 0.0; // Figure out the shit means tomorrow
	}

	// Increase the salary of an Employee
	@Override
	public double incrementSalary(double amount) 
	{
		if ((salary + amount) > 150000) 
		{
			return salary = 150000;
		} 
		else 
		{
			return salary += amount;
		}
	}

	public void read() {
		JTextField txtEmpNo = new JTextField();
		txtEmpNo.setText("" + this.getemployeeNumber());
		JTextField txtTitle = new JTextField();
		txtTitle.requestFocus();

		JTextField txtFName = new JTextField();
		JTextField txtLName = new JTextField();
		JTextField txtDayOfBirth = new JTextField();
		JTextField txtMonthOfBirth = new JTextField();
		JTextField txtYearOfBirth = new JTextField();
		JTextField txtDayOfStart = new JTextField();
		JTextField txtMonthOfStart = new JTextField();
		JTextField txtYearOfStart = new JTextField();
		JTextField txtSalary = new JTextField();

		Object[] message = { "Employee Number:", txtEmpNo, "Employee Title:", txtTitle, "Employee First Name:",
				txtFName, "Employee Last Name:", txtLName,"Employee Salary:", txtSalary ,"Employee Day of Birth:", txtDayOfBirth,
				"Employee Month of Birth:", txtMonthOfBirth, "Employee Year of Birth:", txtYearOfBirth,
				"Employee Day of Start:", txtDayOfStart, "Employee Month of Start:", txtMonthOfStart,
				"Employee Year of Start:", txtYearOfStart,

		};

		int option = JOptionPane.showConfirmDialog(null, message, "Enter Empoyee details",
				JOptionPane.OK_CANCEL_OPTION);

		if (option == JOptionPane.OK_OPTION) {
			this.empNumber = Integer.parseInt(txtEmpNo.getText());
			this.name.setTitle(txtTitle.getText());
			this.name.setFName(txtFName.getText());
			this.name.setSName(txtLName.getText());
			
				try {
					super.setDOB(new Date(Integer.parseInt(txtDayOfBirth.getText()), Integer.parseInt(txtMonthOfBirth.getText()),
							Integer.parseInt(txtDayOfStart.getText())));
				} catch (NumberFormatException ioE) {
					
				}

				try {
					this.setStartDate(new Date(Integer.parseInt(txtDayOfStart.getText()), Integer.parseInt(txtMonthOfStart.getText()),
							Integer.parseInt(txtYearOfStart.getText())));
				} catch (NumberFormatException ioE) {
					
				}
				try {
					this.salary = Integer.parseInt(txtSalary.getText());
				} catch (NumberFormatException ioE) {
					
				}
			}
		}
	}