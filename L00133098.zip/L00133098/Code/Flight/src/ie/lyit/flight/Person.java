package ie.lyit.flight;

import java.io.Serializable;

public abstract class Person implements Serializable
{
	protected Name name;
    protected Date dateOfBirth;

    public Person()
    {
        name = new Name();
        dateOfBirth = new Date();
    }

    public Person(String title, String firstName, String secondName, int day, int month, int year){
        name = new Name(title, firstName, secondName);
        dateOfBirth = new Date(day, month, year);
    }

    public void setName(String fName){
        name.setFName(fName);
    }

    public void setDOB(Date DateOfBirthan){
    	this.dateOfBirth= DateOfBirthan;
    }

    public String getName(){
        return name.getFName();
    }

    public Date getDOB(){
        return dateOfBirth;
    }

    public String toString(){
    	return name.toString() + "\n"
    		  +"Birthday: " + dateOfBirth.toString();
    }

    public boolean equals(Object perObject){
        Person personObject;
    	  if(perObject instanceof Person){
            personObject = (Person)perObject;
        }
        else{
            return false;
        }
        
        return(name.equals(personObject.name) &&
               dateOfBirth.equals(personObject.dateOfBirth));
    }
}
