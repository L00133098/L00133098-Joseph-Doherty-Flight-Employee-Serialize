package ie.lyit.flight;

import java.io.Serializable;

public class Name implements Serializable
{
	private String title;
	private String firstName;
	private String surname;

	// Default Constructor
	public Name() 
	{
		title = null;
		firstName = null;
		surname = null;
	}

	// Initizalized Constructor
	    public Name(String title, String firstName, String surname) {
		this.title = title;
		this.firstName = firstName;
		this.surname = surname;
	}


	// Getters and Setters
	public String getTitle() {
		return title;
	}

	public String getFName() {
		return firstName;
	}

	public String getSName() {
		return surname;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setFName(String firstName) {
		this.firstName = firstName;
	}

	public void setSName(String surname) {
		this.surname = surname;
	}


	// Check if person is a female
	public boolean isFemale() {
		String titles [] = {"Miss", "Ms", "Mrs"};
		for(int i = 0; i < titles.length; i++) {
			if(title == titles[i]) {
				return true;
			}
		}
		return false;
	}

	// toString method
	public String toString() {
		return "Title: " + title + "\n"
			   + "First Name: " + firstName + "\n"
			   + "Surname: " + surname;
	}

	// equals method
	public boolean equals(Name obj) {
		return(title == obj.title
		   && firstName == obj.firstName
		   && surname == obj.surname);
	}
}
