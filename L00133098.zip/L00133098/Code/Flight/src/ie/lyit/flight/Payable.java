package ie.lyit.flight;

public abstract interface Payable{
    abstract double calculateWage(double taxPercentage);
    abstract double incrementSalary(double amount);
}
