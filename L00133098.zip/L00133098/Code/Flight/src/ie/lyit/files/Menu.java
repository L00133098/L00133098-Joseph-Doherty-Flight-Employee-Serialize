package ie.lyit.files;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Menu 
{
   
private int option;
   
   public void display()
   {
     System.out.println("\t1. Add");
	 System.out.println("\t2. List");
	 System.out.println("\t3. View");
	 System.out.println("\t4. Edit");
	 System.out.println("\t5. Delete");
	 System.out.println("\t6. Quit");		
   }
	
   public void readOption()
   {
	   try {
      Scanner kbInt = new Scanner(System.in);
  	  System.out.println("\n\tEnter Option [1|2|3|4|5|6]");
   	  option=kbInt.nextInt();
	   }
   	  catch (InputMismatchException e)
   	  {
   		 System.out.println("Enter right Numbe between 1 - 6");
   	  }
	   
   }
					
	public int getOption()
	{
	   return option;
	}	
}
	