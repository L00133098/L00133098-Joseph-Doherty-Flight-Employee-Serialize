//package ie.lyit.testers;
//import ie.lyit.flight.Employee;
//
//public class EmpTester{
//    public static void main(String [] args){
//     //   Employee emp2 = new Employee("Mrs", "James","Smith", 32, 3, 1996, 1000.0, 2017, 10);
//       // Employee emp3 = new Employee("Mrs", "Jasmes", "Smith", 1, 2,  1996, 1000.0, 2017, 0);
//       // Employee emp4 = new Employee("Mr", "James", "Smith", 1, 2, 1996, 1000.0, 2017, 0); 
//
//        System.out.print(emp2.toString() + "\n\n" +
//                                  emp3.toString() + "\n\n" + 
//                                  emp4.toString());
//
//    }
//}
