package ie.lyit.testers;
import java.util.*;

import ie.lyit.flight.Name;
public class NameTester {

	public static void main(String[] args) {
		//Name names1 = new Name();
		Name names2 = new Name("Miss", "Mary", "McGinley"); 
	
		ArrayList<Name> names = new ArrayList<Name>(); 
		names.add(new Name("Mrs", "Declan", "McGinley"));
		names.add(new Name("Mister", "Ann", "McGinley"));
		names.add(new Name("Miss", "Mary", "McGinley"));
		
		if(nameSearch(names2, names)) {
			System.out.print("Hello World");
		}
		else {
			System.out.print("Hello");
		}
	}
	
	 static boolean nameSearch(Name name, ArrayList<Name> aL) {
		for(Name names : aL) {
			if(names.equals(name)) {
				return true;
			}
		}
		return false; 
	}

}
