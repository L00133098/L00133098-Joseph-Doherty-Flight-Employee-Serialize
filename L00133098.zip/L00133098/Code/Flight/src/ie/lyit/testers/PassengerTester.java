package ie.lyit.testers;
import ie.lyit.flight.Passenger;

public class PassengerTester{
   public static void main(String [] args){
      Passenger pass2 = new Passenger("Mrs", "James", "Smith", 1, 2, 1997, 2, true);
      Passenger pass3 = new Passenger("Mrs", "James", "Smith", 1, 2, 1997, 3, true);
   
      if(pass2.equals(pass3)){
         System.out.print("true");
      }
      else{
         System.out.print("false");
      }
   
          //System.out.print(pass2.toString() + "\n\n");
   //        System.out.print(pass2.getName());
   }
}
