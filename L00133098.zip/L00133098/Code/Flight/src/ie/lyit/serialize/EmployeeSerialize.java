package ie.lyit.serialize;

import java.util.*;

import java.util.ArrayList;

import ie.lyit.flight.Employee;

import java.io.*;

public class EmployeeSerialize implements Serializable
{
   // Delcares Arraylist Employee
	private ArrayList<Employee> employees;
	Scanner scan = new Scanner(System.in);
	//Change the location of the .ser file
	private final String FILENAME = "X:\\Software Implementation\\Project.Empoyee.ser";
			                          //"X:\\Software Implementation\\Project.Empoyee.ser";
                                     //"C:\\Users\\jd-no\\Desktop\\Code\Flight.Empoyee.ser";
	// Default Constructor
	public EmployeeSerialize() 
	{
		// Construct bookList ArrayList
		employees = new ArrayList<Employee>();
	}
 
	public void add()
	{
		// Create a Book object
		Employee employee = new Employee();
		// Read its details
		employee.read();
		// Removes Duplicate
		DuplicateRemover();
		// And add it to the books ArrayList
		employees.add(employee);
	}
	
	// List Method
	public void list() {
		// for every Book object in books
		for (Employee tmpEmployee : employees)
			// display it
			System.out.println(tmpEmployee);
	}
    // View Method
	public Employee view() 
	{

		System.out.print("Enter in Number to view");
		int answer = scan.nextInt();
		for (Employee tmpEmployee : employees) {
			// for every Book object in books
			if (tmpEmployee.getemployeeNumber() == answer) {
				System.out.println(tmpEmployee);
				return tmpEmployee;

			}
		}
		return null;
	}
   //Edit Method
	public void edit() 
	{
		System.out.print("Enter in Number to edit ");
		Employee employeea = view();
		if (employees !=null)
		{
			// display it
			int index = employees.indexOf(employeea);
			employeea.read();
			employees.set(index, employeea);
			
		}
	}
	// Delete Method
	public void delete() 
	{
    System.out.println("Enter in Number to  delete");
    boolean efound = false;
	int answer2 = scan.nextInt();
	for(int i =0; i< employees.size(); i++)
	{
		
		if (employees.get(i).getemployeeNumber() == answer2)
		{
		
			employees.remove(i);
			i--;
			efound= true;	
		}
	}
	}
    // Remove Duplicate Method 
	public void DuplicateRemover()
	 {
	
		for (int i = 0; i < employees.size(); i++)
		{
			for (int j = 0; j < employees.size(); j++)
			{
				if (i != j)
				{

					if (employees.get(i).equals(employees.get(j))) 
					{
						employees.remove(j);	
					}
				}
			}
		}
	}

	// This method will deserialize the employee ArrayList when called,
	// i.e. it will restore the ArrayList from the file employee.ser
	public void deserialize()
	{
		ObjectInputStream is = null;
		try
		{
			// Deserialize the ArrayList...
			FileInputStream fileStream = new FileInputStream(FILENAME);
			 is = new ObjectInputStream(fileStream);
			employees = (ArrayList<Employee>) is.readObject();
		} catch (FileNotFoundException fNFE) 
		
		{
			System.out.println("Cannot create file to store books.");
		} catch (IOException ioE) 
		
		{
		 System.out.println("sss" + ioE.getMessage());
		} catch (Exception e) 
		
		{
			System.out.println(e.getMessage());
		}
		
		finally 
		{
		try 
		{
			is.close();
		}	 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
		}
	}
	
	// This writes and saves in the Array
	public void serialize() 
	{
		ObjectOutputStream os =null;
		try
		{
			// Serialize the ArrayList
			FileOutputStream fileStream = new FileOutputStream(FILENAME);
			os = new ObjectOutputStream(fileStream);
			os.writeObject(employees);
			
		} catch (FileNotFoundException fNFE) 
		{
			System.out.println("Cannot create file");
		} catch (IOException ioE) {
			System.out.println(ioE.getMessage());
		}
		finally 
		{
		try 
		{
			os.close();
		}	 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
		}
	}
	// This Makes the file
	public void makeFile()
	{
		
			// Deserialize the ArrayList...
			File employee = new File(FILENAME);

			if(employee.isFile()== true)
				System.out.println("File Employee.ser is found");
			
			else if(employee.isFile()== false)
			{
				try {
					employee.createNewFile();
				}
				catch(Exception e)
				{
				System.out.println(e.getMessage());
				}
			}
	}
	}
	